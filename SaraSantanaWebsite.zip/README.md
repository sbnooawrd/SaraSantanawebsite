# SaraSantana’s Microblading Website

This is the official website for SaraSantana’s Microblading services. Built with React, deployed on Vercel.

## Features
- Homepage with bold branding
- Booking system ($350 services)
- Post-care info
- Restrictions page
- Gallery
- Waiver + No-show policy

## Deployment
Deployed via Vercel at: https://sarasantanas.vercel.app