import React from 'react';
import Home from './Home';
import './styles.css';

function App() {
  return <Home />;
}

export default App;